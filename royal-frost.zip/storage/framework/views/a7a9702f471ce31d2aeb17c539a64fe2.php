<div <?php echo e($attributes->class('h-[26.44px] pt-[8.44px]')); ?>>
    <p class="eyebrow-line"><span class="h-px w-6 bg-accent"></span><?php echo e($slot); ?></p>
</div>
<?php /**PATH C:\Users\Lenovo\Herd\royal_frost\resources\views/components/eyebrow.blade.php ENDPATH**/ ?>