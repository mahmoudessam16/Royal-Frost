<?php $f = $t['footer']; ?>

<footer class="overflow-hidden border-t border-black/20 bg-paper">
    <?php if (isset($component)) { $__componentOriginala766c2d312d6f7864fe218e2500d2bba = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala766c2d312d6f7864fe218e2500d2bba = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.container','data' => ['class' => 'pt-16 md:pt-24']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('container'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'pt-16 md:pt-24']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

        <div class="flex flex-col gap-12 lg:flex-row lg:justify-between">
            <div class="max-w-[224px]">
                <p class="font-display text-[22px] leading-[33px] font-bold tracking-[-0.025em] text-black"><?php echo e($t['meta']['name']); ?></p>
                <p class="pt-5 text-[15px] leading-[24.4px] text-black/55"><?php echo e($f['tagline']); ?></p>
            </div>

            <div class="grid grid-cols-2 gap-10 sm:grid-cols-3 lg:w-[704px]">
                <div>
                    <p class="font-mono text-[11px] leading-[16.5px] tracking-[0.18em] text-black/40 uppercase"><?php echo e($f['company']); ?></p>
                    <ul class="space-y-3 pt-5 font-display text-[15px] leading-[22.5px] text-black/75">
                        <li><a class="transition-colors hover:text-accent" href="<?php echo e(route('home')); ?>"><?php echo e($t['nav']['home']); ?></a></li>
                        <li><a class="transition-colors hover:text-accent" href="<?php echo e(route('about')); ?>"><?php echo e($t['nav']['about']); ?></a></li>
                        <li><a class="transition-colors hover:text-accent" href="<?php echo e(route('services')); ?>"><?php echo e($t['nav']['services']); ?></a></li>
                        <li><a class="transition-colors hover:text-accent" href="<?php echo e(route('contact')); ?>"><?php echo e($f['contact_us']); ?></a></li>
                    </ul>
                </div>
                <div>
                    <p class="font-mono text-[11px] leading-[16.5px] tracking-[0.18em] text-black/40 uppercase"><?php echo e($t['nav']['services']); ?></p>
                    <ul class="space-y-3 pt-5 font-display text-[15px] leading-[22.5px] text-black/75">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $f['service_links']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $anchor => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                            <li><a class="transition-colors hover:text-accent" href="<?php echo e(route('services')); ?>#<?php echo e($anchor); ?>"><?php echo e($label); ?></a></li>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                    </ul>
                </div>
                <div class="col-span-2 sm:col-span-1">
                    <p class="font-mono text-[11px] leading-[16.5px] tracking-[0.18em] text-black/40 uppercase"><?php echo e($f['contact']); ?></p>
                    <ul class="space-y-3 pt-5 text-[15px] leading-[22.5px]">
                        <li class="text-black/75" dir="ltr" style="text-align: start"><a class="transition-colors hover:text-accent" href="tel:<?php echo e(preg_replace('/\s+/', '', $f['phone'])); ?>"><?php echo e($f['phone']); ?></a></li>
                        <li class="text-black/75"><a class="transition-colors hover:text-accent" href="mailto:<?php echo e($f['email']); ?>"><?php echo e($f['email']); ?></a></li>
                        <li class="text-black/55"><?php echo e($f['address']); ?></li>
                    </ul>
                </div>
            </div>
        </div>

        <div aria-hidden="true" class="pt-12 select-none md:pt-20">
            <p class="h-[0.9em] overflow-hidden font-display text-[clamp(64px,17.7vw,226px)] leading-[1.18] tracking-[-0.024em] whitespace-nowrap text-black/5 md:h-[266.5px]"><?php echo e($t['meta']['name']); ?></p>
        </div>

        <div class="flex flex-col gap-3 border-t border-black/10 py-6 text-[13px] leading-[19.5px] text-black/45 sm:flex-row sm:items-center sm:justify-between">
            <p><?php echo e($f['rights']); ?></p>
            <div class="flex items-center gap-6">
                <a href="#" class="transition-colors hover:text-accent"><?php echo e($f['privacy']); ?></a>
                <a href="#" class="transition-colors hover:text-accent"><?php echo e($f['terms']); ?></a>
                <span class="font-mono">
                    <a href="<?php echo e(route(Route::currentRouteName(), ['locale' => 'en'])); ?>" class="transition-colors hover:text-accent <?php echo e($locale === 'en' ? 'text-accent' : ''); ?>">EN</a>
                    /
                    <a href="<?php echo e(route(Route::currentRouteName(), ['locale' => 'ar'])); ?>" class="transition-colors hover:text-accent <?php echo e($locale === 'ar' ? 'text-accent' : ''); ?>">AR</a>
                </span>
            </div>
        </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala766c2d312d6f7864fe218e2500d2bba)): ?>
<?php $attributes = $__attributesOriginala766c2d312d6f7864fe218e2500d2bba; ?>
<?php unset($__attributesOriginala766c2d312d6f7864fe218e2500d2bba); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala766c2d312d6f7864fe218e2500d2bba)): ?>
<?php $component = $__componentOriginala766c2d312d6f7864fe218e2500d2bba; ?>
<?php unset($__componentOriginala766c2d312d6f7864fe218e2500d2bba); ?>
<?php endif; ?>
</footer>
<?php /**PATH C:\Users\Lenovo\Herd\royal_frost\resources\views/partials/footer.blade.php ENDPATH**/ ?>