<!DOCTYPE html>
<html lang="<?php echo e($locale); ?>" dir="<?php echo e($dir); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo e(isset($title) ? $title.' | '.$t['meta']['name'] : $t['meta']['title']); ?></title>
    <meta name="description" content="<?php echo e($t['meta']['description']); ?>">
    <meta name="theme-color" content="#151719">
    <link rel="icon" href="<?php echo e(asset('favicon.svg')); ?>" type="image/svg+xml">
    <link rel="icon" href="<?php echo e(asset('favicon.ico')); ?>" sizes="32x32">
    <link rel="apple-touch-icon" href="<?php echo e(asset('apple-touch-icon.png')); ?>">
    <link rel="alternate" hreflang="en" href="<?php echo e(route(Route::currentRouteName(), ['locale' => 'en'])); ?>">
    <link rel="alternate" hreflang="ar" href="<?php echo e(route(Route::currentRouteName(), ['locale' => 'ar'])); ?>">
    <?php echo $__env->yieldPushContent('head'); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body>
    <?php echo $__env->make('partials.header', ['light' => $headerLight ?? false], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <main>
        <?php echo $__env->yieldContent('content'); ?>
    </main>

    <?php echo $__env->make('partials.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</body>
</html>
<?php /**PATH C:\Users\Lenovo\Herd\royal_frost\resources\views/layouts/app.blade.php ENDPATH**/ ?>