
<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['image', 'eyebrow', 'opacity' => 0.45, 'fade' => 'bottom', 'size' => 'text-[clamp(2.75rem,6.9vw,5.5rem)]']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['image', 'eyebrow', 'opacity' => 0.45, 'fade' => 'bottom', 'size' => 'text-[clamp(2.75rem,6.9vw,5.5rem)]']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<section class="relative flex h-[max(620px,39.4vw)] items-end overflow-hidden bg-ink">
    <img src="<?php echo e(site_image($image)); ?>" alt="" fetchpriority="high" decoding="async"
         class="absolute inset-0 size-full object-cover" style="opacity: <?php echo e($opacity); ?>">
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($fade === 'top'): ?>
        <div aria-hidden="true" class="absolute inset-0 bg-gradient-to-t from-ink from-[12%] to-transparent to-[40%]"></div>
    <?php else: ?>
        <div aria-hidden="true" class="absolute inset-0 bg-gradient-to-b from-transparent from-[75%] to-black/20"></div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    <?php if (isset($component)) { $__componentOriginala766c2d312d6f7864fe218e2500d2bba = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala766c2d312d6f7864fe218e2500d2bba = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.container','data' => ['class' => 'relative pt-40 pb-12 md:pb-16']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('container'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'relative pt-40 pb-12 md:pb-16']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

        <p class="inline-flex h-7 items-center bg-accent px-2 font-mono text-xs leading-[18px] tracking-[0.18em] text-white uppercase"><?php echo e($eyebrow); ?></p>
        <h1 class="reveal max-w-[896px] pt-6 font-display <?php echo e($size); ?> leading-[0.98] tracking-[-0.02em] text-paper"><?php echo e($slot); ?></h1>
        <p class="reveal max-w-[637px] pt-6 text-lg leading-[1.4] text-white/70 md:text-xl" style="--d: 100ms"><?php echo e($body); ?></p>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala766c2d312d6f7864fe218e2500d2bba)): ?>
<?php $attributes = $__attributesOriginala766c2d312d6f7864fe218e2500d2bba; ?>
<?php unset($__attributesOriginala766c2d312d6f7864fe218e2500d2bba); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala766c2d312d6f7864fe218e2500d2bba)): ?>
<?php $component = $__componentOriginala766c2d312d6f7864fe218e2500d2bba; ?>
<?php unset($__componentOriginala766c2d312d6f7864fe218e2500d2bba); ?>
<?php endif; ?>
</section>
<?php /**PATH C:\Users\Lenovo\Herd\royal_frost\resources\views/components/page-hero.blade.php ENDPATH**/ ?>