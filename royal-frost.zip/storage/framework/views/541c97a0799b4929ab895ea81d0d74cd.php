<?php $h = $t['home']['hero']; ?>

<section class="relative flex h-[max(680px,min(100svh,56.25vw))] items-center overflow-hidden bg-ink">
    <img src="<?php echo e(site_image('hero.webp')); ?>" alt="" fetchpriority="high" decoding="async" class="absolute inset-0 size-full object-cover">
    <div aria-hidden="true" class="absolute inset-0 bg-black/20"></div>
    <div aria-hidden="true" class="absolute inset-y-0 start-0 w-[64%] bg-gradient-to-r from-black/55 to-transparent rtl:bg-gradient-to-l"></div>

    <?php if (isset($component)) { $__componentOriginala766c2d312d6f7864fe218e2500d2bba = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala766c2d312d6f7864fe218e2500d2bba = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.container','data' => ['class' => 'relative pt-16']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('container'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'relative pt-16']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

        <div class="max-w-[835px]">
            <p class="inline-flex h-7 items-center bg-accent px-2 font-mono text-xs leading-[18px] tracking-[0.18em] text-white uppercase"><?php echo e($h['eyebrow']); ?></p>
            <h1 class="reveal pt-8 font-display text-[clamp(3rem,5vw,8rem)] leading-[0.98] tracking-[-0.02em] text-paper"><?php echo e($h['title']); ?><span class="text-white"><?php echo e($h['accent']); ?></span></h1>
            <p class="reveal max-w-[508px] pt-8 text-lg leading-[1.4625] text-white/70 md:text-xl" style="--d: 100ms"><?php echo e($h['body']); ?></p>
            <div class="reveal flex flex-wrap gap-4 pt-10" style="--d: 200ms">
                <a href="<?php echo e(route('contact')); ?>" class="btn btn-lg btn-solid"><?php echo e($h['primary']); ?> <?php if (isset($component)) { $__componentOriginal35256cbc8835b79b0ad2169177d019cb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal35256cbc8835b79b0ad2169177d019cb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.arrow','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('arrow'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal35256cbc8835b79b0ad2169177d019cb)): ?>
<?php $attributes = $__attributesOriginal35256cbc8835b79b0ad2169177d019cb; ?>
<?php unset($__attributesOriginal35256cbc8835b79b0ad2169177d019cb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal35256cbc8835b79b0ad2169177d019cb)): ?>
<?php $component = $__componentOriginal35256cbc8835b79b0ad2169177d019cb; ?>
<?php unset($__componentOriginal35256cbc8835b79b0ad2169177d019cb); ?>
<?php endif; ?></a>
                <a href="<?php echo e(route('services')); ?>" class="btn btn-lg btn-outline-light"><?php echo e($h['secondary']); ?></a>
            </div>
        </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala766c2d312d6f7864fe218e2500d2bba)): ?>
<?php $attributes = $__attributesOriginala766c2d312d6f7864fe218e2500d2bba; ?>
<?php unset($__attributesOriginala766c2d312d6f7864fe218e2500d2bba); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala766c2d312d6f7864fe218e2500d2bba)): ?>
<?php $component = $__componentOriginala766c2d312d6f7864fe218e2500d2bba; ?>
<?php unset($__componentOriginala766c2d312d6f7864fe218e2500d2bba); ?>
<?php endif; ?>
</section>
<?php /**PATH C:\Users\Lenovo\Herd\royal_frost\resources\views/sections/home/hero.blade.php ENDPATH**/ ?>