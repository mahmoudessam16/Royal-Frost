<?php $w = $t['home']['work']; ?>

<section class="bg-white">
    <?php if (isset($component)) { $__componentOriginala766c2d312d6f7864fe218e2500d2bba = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala766c2d312d6f7864fe218e2500d2bba = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.container','data' => ['class' => 'py-16 md:py-24 lg:py-32']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('container'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'py-16 md:py-24 lg:py-32']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

        <?php if (isset($component)) { $__componentOriginalf396d8ec30310aa6ec0c9d9f36fca53d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf396d8ec30310aa6ec0c9d9f36fca53d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.section-head','data' => ['eyebrow' => $w['eyebrow'],'class' => 'text-ink']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('section-head'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['eyebrow' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($w['eyebrow']),'class' => 'text-ink']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>
<?php echo e($w['title']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf396d8ec30310aa6ec0c9d9f36fca53d)): ?>
<?php $attributes = $__attributesOriginalf396d8ec30310aa6ec0c9d9f36fca53d; ?>
<?php unset($__attributesOriginalf396d8ec30310aa6ec0c9d9f36fca53d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf396d8ec30310aa6ec0c9d9f36fca53d)): ?>
<?php $component = $__componentOriginalf396d8ec30310aa6ec0c9d9f36fca53d; ?>
<?php unset($__componentOriginalf396d8ec30310aa6ec0c9d9f36fca53d); ?>
<?php endif; ?>

        <div class="grid gap-x-10 gap-y-14 pt-14 md:grid-cols-2">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $w['items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                <article class="reveal group <?php echo e($n % 2 === 1 ? 'md:pt-16' : ''); ?>" style="--d: <?php echo e(($n % 2) * 100); ?>ms">
                    <div class="relative aspect-[524/327.5] overflow-hidden bg-stone">
                        <img src="<?php echo e(site_image('work-'.($n + 1).'.webp')); ?>" alt="" loading="lazy" decoding="async"
                             class="absolute inset-0 size-full object-cover transition-transform duration-700 group-hover:scale-105">
                    </div>
                    <div class="flex items-start justify-between gap-4 pt-5">
                        <div>
                            <p class="font-mono text-xs leading-[18px] text-accent"><?php echo e($item['index']); ?></p>
                            <h3 class="h3-lg pt-2 text-ink transition-colors group-hover:text-accent"><?php echo e($item['title']); ?></h3>
                            <p class="flex flex-wrap gap-x-5 pt-2 font-mono text-xs leading-[18px]">
                                <span class="text-muted"><?php echo e($item['meta'][0]); ?></span>
                                <span class="text-accent"><?php echo e($item['meta'][1]); ?></span>
                                <span class="text-muted"><?php echo e($item['meta'][2]); ?></span>
                            </p>
                        </div>
                        <span class="relative mt-2 grid size-9 shrink-0 place-items-center border-[1.2px] border-ink/20 transition-[transform,border-color] duration-300 group-hover:rotate-45 group-hover:border-accent">
                            <img src="<?php echo e(asset('icons/diag-arrow-dark.svg')); ?>" alt="" width="16" height="16" class="size-4 group-hover:hidden">
                            <img src="<?php echo e(asset('icons/diag-arrow-orange.svg')); ?>" alt="" width="16" height="16" class="hidden size-4 group-hover:block">
                        </span>
                    </div>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(! empty($item['desc'])): ?>
                        <div class="pt-4">
                            <p class="max-w-[512px] text-[15px] leading-[24.4px] text-muted"><?php echo e($item['desc']); ?></p>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(! empty($item['result'])): ?>
                                <p class="max-w-[512px] pt-3 text-sm leading-[22.75px] text-ink"><?php echo e($item['result']); ?></p>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </div>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </article>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
        </div>

        <div class="reveal pt-14">
            <a href="<?php echo e(route('services')); ?>" class="btn btn-sm btn-outline-dark"><?php echo e($w['cta']); ?> <?php if (isset($component)) { $__componentOriginal35256cbc8835b79b0ad2169177d019cb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal35256cbc8835b79b0ad2169177d019cb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.arrow','data' => ['tone' => 'dark','class' => 'group-hover:brightness-0 group-hover:invert']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('arrow'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['tone' => 'dark','class' => 'group-hover:brightness-0 group-hover:invert']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal35256cbc8835b79b0ad2169177d019cb)): ?>
<?php $attributes = $__attributesOriginal35256cbc8835b79b0ad2169177d019cb; ?>
<?php unset($__attributesOriginal35256cbc8835b79b0ad2169177d019cb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal35256cbc8835b79b0ad2169177d019cb)): ?>
<?php $component = $__componentOriginal35256cbc8835b79b0ad2169177d019cb; ?>
<?php unset($__componentOriginal35256cbc8835b79b0ad2169177d019cb); ?>
<?php endif; ?></a>
        </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala766c2d312d6f7864fe218e2500d2bba)): ?>
<?php $attributes = $__attributesOriginala766c2d312d6f7864fe218e2500d2bba; ?>
<?php unset($__attributesOriginala766c2d312d6f7864fe218e2500d2bba); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala766c2d312d6f7864fe218e2500d2bba)): ?>
<?php $component = $__componentOriginala766c2d312d6f7864fe218e2500d2bba; ?>
<?php unset($__componentOriginala766c2d312d6f7864fe218e2500d2bba); ?>
<?php endif; ?>
</section>
<?php /**PATH C:\Users\Lenovo\Herd\royal_frost\resources\views/sections/home/work.blade.php ENDPATH**/ ?>