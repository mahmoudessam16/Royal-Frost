<?php
    $current = Route::currentRouteName();
    $other = $locale === 'en' ? 'ar' : 'en';
    $links = [
        ['home', $t['nav']['home']],
        ['about', $t['nav']['about']],
        ['services', $t['nav']['services']],
    ];
?>

<header data-header="<?php echo e($light ? 'light' : 'dark'); ?>" class="pointer-events-none fixed inset-x-0 top-3 z-50 px-4 md:top-[34px]">
    <div data-header-bar class="hbar pointer-events-auto mx-auto flex w-full max-w-[1089px] items-center justify-between px-[14px] py-[11px]">
        <a href="<?php echo e(route('home')); ?>" class="font-display text-[28.6px] leading-[28.6px] font-bold tracking-[-0.025em]">
            <?php echo e($t['meta']['name']); ?>

        </a>

        <nav aria-label="Main" class="hidden items-center gap-[17px] lg:flex">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$route, $label]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                <a href="<?php echo e(route($route)); ?>" class="hbar-link" <?php if($current === $route): ?> aria-current="page" <?php endif; ?>><?php echo e($label); ?></a>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
        </nav>

        <div class="flex items-center gap-3">
            <div class="hidden items-center gap-1 font-mono text-xs leading-[18px] sm:flex" aria-label="Language">
                <a href="<?php echo e(route($current, ['locale' => 'en'])); ?>" hreflang="en" lang="en"
                   class="transition-colors hover:text-accent <?php echo e($locale === 'en' ? 'text-accent' : 'opacity-70'); ?>">EN</a>
                <span class="opacity-40">/</span>
                <a href="<?php echo e(route($current, ['locale' => 'ar'])); ?>" hreflang="ar" lang="ar"
                   class="transition-colors hover:text-accent <?php echo e($locale === 'ar' ? 'text-accent' : 'opacity-70'); ?>">AR</a>
            </div>
            <a href="<?php echo e(route($current, ['locale' => $other])); ?>" hreflang="<?php echo e($other); ?>"
               class="font-mono text-xs underline-offset-4 hover:text-accent hover:underline sm:hidden"><?php echo e(strtoupper($other)); ?></a>
            <a href="<?php echo e(route('contact')); ?>" class="btn btn-sm btn-solid hidden !text-white md:inline-flex"><?php echo e($t['nav']['cta']); ?></a>
            <button type="button" data-menu-toggle aria-label="Menu" aria-expanded="false"
                    class="flex size-10 flex-col items-center justify-center gap-1.5 lg:hidden">
                <span class="menu-bar"></span>
                <span class="menu-bar"></span>
            </button>
        </div>
    </div>

    <div data-menu hidden class="pointer-events-auto mx-auto mt-px flex max-w-[1089px] flex-col bg-ink/95 p-4 text-white backdrop-blur-md lg:hidden">
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$route, $label]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
            <a href="<?php echo e(route($route)); ?>" class="py-3 font-display text-lg transition-colors hover:text-accent <?php echo e($current === $route ? 'text-accent' : ''); ?>"><?php echo e($label); ?></a>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
        <a href="<?php echo e(route('contact')); ?>" class="btn btn-sm btn-solid mt-2 !text-white"><?php echo e($t['nav']['cta']); ?></a>
    </div>
</header>
<?php /**PATH C:\Users\Lenovo\Herd\royal_frost\resources\views/partials/header.blade.php ENDPATH**/ ?>