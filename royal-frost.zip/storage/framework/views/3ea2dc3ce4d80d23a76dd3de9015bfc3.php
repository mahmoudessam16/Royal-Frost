<?php
    $p = $t['home']['products'];
    $imgs = ['building-materials', 'supply-industrial', 'supply-electrical', 'supply-plumbing', 'supply-office', 'supply-safety'];
?>

<section class="bg-white">
    <?php if (isset($component)) { $__componentOriginala766c2d312d6f7864fe218e2500d2bba = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala766c2d312d6f7864fe218e2500d2bba = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.container','data' => ['class' => 'py-16 md:py-24 lg:py-32']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('container'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'py-16 md:py-24 lg:py-32']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

        <div class="flex flex-col justify-between gap-8 lg:flex-row lg:items-center">
            <div class="pt-6">
                <h2 class="h2 reveal text-ink"><?php echo e($p['title']); ?></h2>
                <p class="reveal max-w-[710px] pt-5 text-[17px] leading-[1.625] text-muted" style="--d: 80ms"><?php echo e($p['body']); ?></p>
            </div>
            <div class="reveal shrink-0">
                <a href="<?php echo e(route('services')); ?>" class="btn btn-sm btn-outline-dark"><?php echo e($p['view_all']); ?> <?php if (isset($component)) { $__componentOriginal35256cbc8835b79b0ad2169177d019cb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal35256cbc8835b79b0ad2169177d019cb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.arrow','data' => ['tone' => 'dark','class' => 'group-hover:brightness-0 group-hover:invert']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('arrow'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['tone' => 'dark','class' => 'group-hover:brightness-0 group-hover:invert']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal35256cbc8835b79b0ad2169177d019cb)): ?>
<?php $attributes = $__attributesOriginal35256cbc8835b79b0ad2169177d019cb; ?>
<?php unset($__attributesOriginal35256cbc8835b79b0ad2169177d019cb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal35256cbc8835b79b0ad2169177d019cb)): ?>
<?php $component = $__componentOriginal35256cbc8835b79b0ad2169177d019cb; ?>
<?php unset($__componentOriginal35256cbc8835b79b0ad2169177d019cb); ?>
<?php endif; ?></a>
            </div>
        </div>

        <div data-tabs>
            <div role="tablist" class="mt-12 flex gap-6 overflow-x-auto border-b border-line pb-5 whitespace-nowrap">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $p['tabs']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n => $tab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                    <button type="button" role="tab" aria-selected="<?php echo e($n === 0 ? 'true' : 'false'); ?>"
                            class="font-display text-[15px] leading-[22.5px] transition-colors hover:text-ink <?php echo e($n === 0 ? 'text-accent' : 'text-muted'); ?>"><?php echo e($tab['label']); ?></button>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
            </div>

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $p['tabs']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n => $tab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                <div role="tabpanel" <?php if($n > 0): ?> hidden <?php endif; ?> class="grid items-center gap-10 pt-10 md:grid-cols-[512px_1fr] md:gap-16">
                    <div class="group relative aspect-[4/3] w-full overflow-hidden bg-stone md:aspect-auto md:h-[384px] md:max-w-[512px]">
                        <img src="<?php echo e(site_image($imgs[$n].'.webp')); ?>" alt="<?php echo e($tab['label']); ?>" loading="lazy" decoding="async"
                             class="absolute inset-0 size-full object-cover transition-transform duration-700 hover:scale-105">
                    </div>
                    <div class="flex max-w-[339px] flex-col items-start gap-[21px] py-[3px]">
                        <p class="font-mono text-xs leading-[18px] tracking-[0.1em] text-accent uppercase"><?php echo e($tab['category']); ?></p>
                        <h3 class="font-display text-[clamp(2rem,3.5vw,2.8rem)] leading-[0.98] tracking-[-0.02em] text-ink"><?php echo e($tab['label']); ?></h3>
                        <p class="text-base leading-[26px] text-muted"><?php echo e($tab['desc']); ?></p>
                        <a href="<?php echo e(route('contact')); ?>" class="btn btn-sm btn-solid"><?php echo e($p['quote']); ?> <?php if (isset($component)) { $__componentOriginal35256cbc8835b79b0ad2169177d019cb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal35256cbc8835b79b0ad2169177d019cb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.arrow','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('arrow'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal35256cbc8835b79b0ad2169177d019cb)): ?>
<?php $attributes = $__attributesOriginal35256cbc8835b79b0ad2169177d019cb; ?>
<?php unset($__attributesOriginal35256cbc8835b79b0ad2169177d019cb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal35256cbc8835b79b0ad2169177d019cb)): ?>
<?php $component = $__componentOriginal35256cbc8835b79b0ad2169177d019cb; ?>
<?php unset($__componentOriginal35256cbc8835b79b0ad2169177d019cb); ?>
<?php endif; ?></a>
                    </div>
                </div>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
        </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala766c2d312d6f7864fe218e2500d2bba)): ?>
<?php $attributes = $__attributesOriginala766c2d312d6f7864fe218e2500d2bba; ?>
<?php unset($__attributesOriginala766c2d312d6f7864fe218e2500d2bba); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala766c2d312d6f7864fe218e2500d2bba)): ?>
<?php $component = $__componentOriginala766c2d312d6f7864fe218e2500d2bba; ?>
<?php unset($__componentOriginala766c2d312d6f7864fe218e2500d2bba); ?>
<?php endif; ?>
</section>
<?php /**PATH C:\Users\Lenovo\Herd\royal_frost\resources\views/sections/home/products.blade.php ENDPATH**/ ?>